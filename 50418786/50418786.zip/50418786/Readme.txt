How to run test1.py:

`python task1.py --test_img ./data/test_img.png --character_folder_path ./data/characters/`

How to run evaluate.py:

`python evaluate.py --preds predicted.json --groundtruth groundtruth.json`

to get the F1 score between generated and the ground truth to measure the performance.